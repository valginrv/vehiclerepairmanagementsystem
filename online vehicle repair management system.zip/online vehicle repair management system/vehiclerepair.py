from flask import Flask, request, render_template, redirect, session, url_for, g
from flask_sqlalchemy import SQLAlchemy
# from sqlalchemy import or_
from datetime import datetime
from werkzeug.utils import secure_filename
from base64 import b64encode, b64decode
import jinja2
import os
# import ibm_db_sa
from flask_session import Session

app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + os.path.join(basedir,'vehiclerepair.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_PERMANT'] = False
app.config['SESSION_TYPE'] = "filesystem"
app.secret_key='123'
Session(app)
db = SQLAlchemy(app)

#mechanicregister

class MechanicRegister(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(50), nullable = False)
    lastname = db.Column(db.String(50), nullable=False)
    email =db.Column(db.String(50), nullable = False, unique = True)
    password = db.Column(db.Integer, nullable = False, unique = True)
    Address = db.Column(db.String(50), nullable=False)
    department = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.Integer, nullable=False)
    img = db.Column(db.Text, nullable=False)
    date_joined = db.Column(db.Date,default = datetime.utcnow)


    def __repr__(self):
        return f"<User : {self.email}>"

class UserRegister(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), nullable=False, unique=True)
    password = db.Column(db.String(50), nullable=False)
    address = db.Column(db.String(50), nullable=False)
    licence_no = db.Column(db.Integer, nullable=False, unique=True)
    mobile = db.Column(db.String(20), nullable=False)
    assignedvehicleId = db.Column(db.String(50), nullable=False)
    profile_pic = db.Column(db.Text, nullable=False)
    date_joined = db.Column(db.DateTime, default=datetime.utcnow)


    def __repr__(self):
        return f"<User :{self.name}>"

with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/mechanic_register')
def mechanic_register():
    return  render_template("mechanicregister.html")

@app.route('/signin')
def signin():
    return  render_template("mechaniclogin.html")

@app.route('/userregister')
def userregister():
    return render_template("userregister.html")


@app.route('/userlogin')
def userlogin():
    return render_template("userlogin.html")



@app.route('/mechanicregister', methods=['GET', 'POST'])
def mechanicregister():
    if request.method == 'POST':
        name = request.form.get('first_name')
        mail = request.form.get('mail')
        dept = request.form.get("department")
        phone = request.form.get('mobile')
        lastname = request.form.get('last_name')
        address = request.form.get('address')
        pic = request.files['profile_pic']
        password = request.form.get('password')
        avail = bool(MechanicRegister.query.filter_by(name=name).first())
        avail1 = bool(MechanicRegister.query.filter_by(password=password).first())
        if avail:
            return render_template('mechanicregister.html', result="email already exist")
        elif avail1:
            return render_template('mechanicregister.html', result="password already exist")
        else:

            query = MechanicRegister(name=name,lastname=lastname, phone=phone, email=mail,img=pic.read(),Address=address,department=dept, password=password)
            db.session.add(query)
            db.session.commit()
            return redirect("/")
    else:
        return redirect("/")

#mechaniclogin

@app.route('/mechaniclogin', methods=['GET', 'POST'])
def mechaniclogin():
   if request.method == 'POST':
        mail = request.form.get('email')
        password = request.form.get('password')
        login = MechanicRegister.query.filter_by(email=mail, password=password).first()
        if login:
            return render_template("mechanicdashboard.html")
        else:

            return render_template("mechaniclogin.html", value = "details wrong")


#userregistration//

@app.route('/userregister', methods=['POST'])
def userr():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']
        address = request.form['address']
        licenceNo = request.form['Licence_No']
        mobile = request.form['mobile']
        assigned_vehicle = request.form['assignedvehicleId']
        profile_pic = request.files['profile_pic']
        # print(f"{first_name},{last_name}, {email}, {password}, {address}, {licenceNo}, {mobile},{assigned_vehicle}, ")
        avail = bool(UserRegister.query.filter_by(email=email).first())
        avail1 = bool(UserRegister.query.filter_by(password=password).first())
    if avail:
        return render_template("userregister.html",data = "email already exist")
    elif avail1:
        return render_template('userregister.html',data = "password already exist")
    else:

        query = UserRegister(first_name=first_name, last_name=last_name, mobile=mobile, email=email, profile_pic=profile_pic.read(), address=address, licence_no=licenceNo,
                             assignedvehicleId=assigned_vehicle, password=password)
        db.session.add(query)
        db.session.commit()
        return redirect("/userlogin")


@app.route("/usersignin", methods=['GET','POST'])
def usersignin():
    name = request.form['name']
    password = request.form['password']
    login = UserRegister.query.filter_by(email=name, password=password).first()
    if login:
        return render_template("userdashboard.html")
    else:

        return render_template("userlogin.html", value="details wrong")




if __name__ == '__main__':
    app.run(debug=True)

